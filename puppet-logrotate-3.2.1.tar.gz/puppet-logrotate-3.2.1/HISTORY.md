## v1.2.8 (2015-09-14)

- Fix hidden unicode character (#8)
- Allow config to be passed in as an hash (#6)
- Fix dependency issue (#7)
- refactor main class (mostly to facilitate #7)
- update test environment to use puppet 4
- switch stdlib fixture to https source

## v1.2.7 (2015-05-06)

- Metadata-only release (just bumped version)

## v1.2.6 (2015-05-06)

- Fix test failures on future parser

## v1.2.5 (2015-05-06)

- Switch some validation code to use validate_re

## v1.2.4 (2015-05-06)

- Add puppet-lint exclusions

## v1.2.3 (2015-05-06)

- More work on testing
- fix warning when running puppet module list caused by "-" instead of "/" in dependencies in metadata

## v1.2.3 (2015-05-06)

- removed (pushed without CHANGELOG update

## v1.2.1 (2015-05-06)

- Update tests, Rakefile, etc.

## v1.2.0 (2015-03-25)

- First release to puppetforge
